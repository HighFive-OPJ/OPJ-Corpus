# Evaluation Results

## test_1
```
              precision    recall  f1-score   support

           0     0.5061    0.5030    0.5046       165
           1     0.0968    0.1034    0.1000        58
           2     0.7307    0.7256    0.7281       430

    accuracy                         0.6141       653
   macro avg     0.4445    0.4440    0.4442       653
weighted avg     0.6176    0.6141    0.6158       653

```
## test_2
```
              precision    recall  f1-score   support

           0     0.6818    0.6250    0.6522       216
           1     0.8506    0.5151    0.6416       431
           2     0.2199    0.6596    0.3298        94

    accuracy                         0.5655       741
   macro avg     0.5841    0.5999    0.5412       741
weighted avg     0.7214    0.5655    0.6051       741

```
## test_3
```
              precision    recall  f1-score   support

           0     0.8281    0.7940    0.8107       267
           1     0.8481    0.9125    0.8791       263
           2     0.8031    0.7757    0.7892       263

    accuracy                         0.8272       793
   macro avg     0.8264    0.8274    0.8263       793
weighted avg     0.8265    0.8272    0.8263       793

```
