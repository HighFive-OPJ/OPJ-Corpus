# Test Set Statistics

Total test sentences: 653

| Category             | Metric     | Value |
|----------------------|------------|-------|
| **Label Distribution** | Label 0    | 165   |
|                      | Label 1    | 58    |
|                      | Label 2    | 430   |
| **Sentence Length**    | Average    | 21.33 |
|                      | Shortest   | 1     |
|                      | Longest    | 95    |
